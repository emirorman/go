-- AlterTable
ALTER TABLE "syncs" ADD COLUMN     "version" INTEGER;
