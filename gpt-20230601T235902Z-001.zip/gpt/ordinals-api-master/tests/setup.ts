// ts-unused-exports:disable-next-line
export default (): void => {
  process.env.CHAINHOOK_NODE_AUTH_TOKEN = 'test';
  process.env.PGDATABASE = 'postgres';
};
