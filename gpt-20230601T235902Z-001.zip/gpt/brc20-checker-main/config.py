tickers_to_ignore = ['', ]  # hide tickers
ticker_to_check = 'BTC REMILIO BABIES'  # the only ticker to show
